Projeto: Brasília Resort - Hotel Fazenda
Arquivos: hotel.html (página exigida), hub.html (página inicial do projeto), assets/

Como publicar:
- Faça upload do conteúdo desta pasta para o GitHub Pages ou Netlify.
- Certifique-se de que 'hub.html' seja a página inicial ou que o avaliador consiga abrir hub.html para navegar até hotel.html.

Observações:
- As imagens usadas foram fornecidas pelo usuário.
- O tema Grandoria foi incluído (se estava no ZIP enviado). Caso faltem estilos, verifique se os arquivos CSS/JS do tema estão presentes na pasta.
